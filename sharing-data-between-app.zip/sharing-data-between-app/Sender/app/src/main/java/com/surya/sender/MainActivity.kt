package com.surya.sender

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "This is from sender.")
        }
        findViewById<Button>(R.id.send_indirect).setOnClickListener {
            startActivity(sendIntent)
        }

        val sendIntent2 = Intent().apply {
            action = Intent.ACTION_SEND
            type = "text/plain"
            `package` = "com.surya.reciever"
            putExtra(Intent.EXTRA_TEXT, "This is from sender.")
        }
        findViewById<Button>(R.id.send_direct).setOnClickListener {
            startActivity(sendIntent2)
        }
    }
}